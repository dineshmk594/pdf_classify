# pdf_classify
To classify the pdf as digital or scanned.

# Output
1 - digital pdf.
0 - scanned pdf.
